package com.lotech.docskikda;

public class ProfileHandler {
    int id;
    String name;
    String phone;
    String local;
    String working_time;

    public ProfileHandler(int id, String name, String phone, String local, String working_time){
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.local = local;
        this.working_time = working_time;
    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getLocal() {
        return local;
    }

    public String getWorking_time() {
        return working_time;
    }


}
