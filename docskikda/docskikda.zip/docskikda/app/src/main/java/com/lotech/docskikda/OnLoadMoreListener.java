package com.lotech.docskikda;

public interface OnLoadMoreListener {
    void onLoadMore();
}
